#!/usr/bin/env/ python3
# -*- coding: utf-8 -*-

from .objective_function import make_objective_function

__author__ = 'Yasuhiro Imoto'
__date__ = '28/12/2017'

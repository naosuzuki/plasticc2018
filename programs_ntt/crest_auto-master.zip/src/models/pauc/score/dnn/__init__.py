#!/usr/bin/env/ python3
# -*- coding: utf-8 -*-

from .model import get_basic_model1

__author__ = 'Yasuhiro Imoto'
__date__ = '04/1/2018'

#!/usr/bin/env/ python3
# -*- coding: utf-8 -*-

from .model import Model

__author__ = 'Yasuhiro Imoto'
__date__ = '04/1/2018'
